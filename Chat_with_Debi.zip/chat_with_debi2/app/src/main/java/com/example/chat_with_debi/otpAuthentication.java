package com.example.chat_with_debi;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

public class otpAuthentication extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_otp_authentication);
    }
}
